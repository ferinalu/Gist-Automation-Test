<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Gist Creation</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>d7e6a87b-a74a-43a6-b216-a1498fadf8b3</testSuiteGuid>
   <testCaseLink>
      <guid>92775e38-7dc5-4ace-bc4a-e17972b6a400</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Create Gist</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a06943bb-9020-430c-bb6d-6cf5dffd7421</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Edit Gist</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4602567c-675f-419d-a593-ca2e5542b503</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/View List Gist</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>48c0141e-20a8-4c23-bb41-f92d951cfc2c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Delete Gist</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
