<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>view_gist_list_label</name>
   <tag></tag>
   <elementGuidId>85621bd5-ccdc-4f3e-adec-0e050a25b25d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'See all of your gists' or . = 'See all of your gists')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>See all of your gists</value>
   </webElementProperties>
</WebElementEntity>
