<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>gist_code_first_line</name>
   <tag></tag>
   <elementGuidId>ce99c1e0-a807-4b5c-89ee-2c6c0c62c5d4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'CodeMirror-code']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>CodeMirror-code</value>
   </webElementProperties>
</WebElementEntity>
