<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>all_gist_label</name>
   <tag></tag>
   <elementGuidId>d38adadc-2d9c-49bd-a7e7-066aeba2ccae</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'HeaderNavlink px-2']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>HeaderNavlink px-2</value>
   </webElementProperties>
</WebElementEntity>
