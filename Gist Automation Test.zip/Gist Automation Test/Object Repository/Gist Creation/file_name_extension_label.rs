<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>file_name_extension_label</name>
   <tag></tag>
   <elementGuidId>7a3dd006-5280-49a8-bf07-30e5954058cb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'gist-header-title css-truncate-target']/*[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class = 'gist-header-title css-truncate-target']/*[1]</value>
   </webElementProperties>
</WebElementEntity>
