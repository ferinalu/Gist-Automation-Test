<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>gist_search_bar</name>
   <tag></tag>
   <elementGuidId>64084e9d-a2e3-47cc-a44d-3a619bf374b3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'header-search-wrapper form-control js-chromeless-input-container']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>header-search-wrapper form-control js-chromeless-input-container</value>
   </webElementProperties>
</WebElementEntity>
